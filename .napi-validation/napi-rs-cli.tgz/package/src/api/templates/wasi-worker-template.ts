export const WASI_WORKER_TEMPLATE = `import fs from 'node:fs'
import { createRequire } from 'node:module'
import { parse } from 'node:path'
import { WASI } from 'node:wasi'
import { parentPort, Worker, workerData } from 'node:worker_threads'

const require = createRequire(import.meta.url)

const {
  instantiateNapiModuleSync,
  MessageHandler,
  getDefaultContext,
  emnapiAsyncWorkPlugin,
  emnapiTSFNPlugin,
} = require('@napi-rs/wasm-runtime')

if (parentPort) {
  parentPort.on('message', (data) => {
    globalThis.onmessage({ data })
  })
}

Object.assign(globalThis, {
  self: globalThis,
  require,
  Worker,
  importScripts: function (f) {
    // oxlint-disable-next-line no-eval -- WASI importScripts polyfill
    ;(0, eval)(fs.readFileSync(f, 'utf8') + '//# sourceURL=' + f)
  },
  postMessage: function (msg) {
    if (parentPort) {
      parentPort.postMessage(msg)
    }
  },
})

const emnapiContext = getDefaultContext()

const __cwd = process.cwd()
const __rootDir =
  (workerData && typeof workerData.rootDir === 'string' && workerData.rootDir) ||
  parse(__cwd).root
const __hostRoot =
  (workerData && typeof workerData.hostRoot === 'string' && workerData.hostRoot) ||
  (process.platform === 'android' ? __cwd : __rootDir)

const handler = new MessageHandler({
  onLoad({ wasmModule, wasmMemory }) {
    const wasi = new WASI({
      version: 'preview1',
      env: process.env,
      preopens: {
        [__rootDir]: __hostRoot,
        [__hostRoot]: __hostRoot,
      },
    })

    return instantiateNapiModuleSync(wasmModule, {
      childThread: true,
      wasi,
      context: emnapiContext,
      // The wasm links a "basic" emnapi archive (no C async-work /
      // threadsafe-function implementations), so every thread that
      // instantiates it must provide the JavaScript implementations
      // through the emnapi plugins.
      plugins: [emnapiAsyncWorkPlugin, emnapiTSFNPlugin],
      overwriteImports(importObject) {
        importObject.env = {
          ...importObject.env,
          ...importObject.napi,
          ...importObject.emnapi,
          memory: wasmMemory,
        }
      },
    })
  },
})

// Tell the loader thread synchronously that this wasm thread died, so its 'exit'
// teardown does not re-enter wasm and wait on this thread forever. emnapi calls
// beforeReportError (which runs emnapi_thread_crashed, so the main thread may
// throw 'unwind' and start exiting) before the 'error' event is even posted.
// A loader that predates the flag passes none.
if (workerData && workerData.crashFlag instanceof Int32Array) {
  const __beforeReportError = handler.beforeReportError
  handler.beforeReportError = function (...args) {
    try {
      Atomics.store(workerData.crashFlag, 0, 1)
    } catch {}
    return __beforeReportError.apply(this, args)
  }
}

globalThis.onmessage = function (e) {
  handler.handle(e)
}
`

export const createWasiBrowserWorkerBinding = (
  fs: boolean,
  errorEvent: boolean,
) => {
  const fsImport = fs
    ? `import {
  instantiateNapiModuleSync,
  MessageHandler,
  WASI,
  createFsProxy,
  emnapiAsyncWorkPlugin,
  emnapiTSFNPlugin,
} from '@napi-rs/wasm-runtime'
import { memfsExported as __memfsExported } from '@napi-rs/wasm-runtime/fs'

const fs = createFsProxy(__memfsExported)`
    : `import {
  instantiateNapiModuleSync,
  MessageHandler,
  WASI,
  emnapiAsyncWorkPlugin,
  emnapiTSFNPlugin,
} from '@napi-rs/wasm-runtime'`
  const errorOutputsAppend = errorEvent
    ? `\n        errorOutputs.push([...arguments])`
    : ''
  const wasiCreation = fs
    ? `const wasi = new WASI({
      fs,
      preopens: {
        '/': '/',
      },
      print: function () {
        // eslint-disable-next-line no-console
        console.log.apply(console, arguments)
      },
      printErr: function () {
        // eslint-disable-next-line no-console
        console.error.apply(console, arguments)${errorOutputsAppend}
      },
    })`
    : `const wasi = new WASI({
      print: function () {
        // eslint-disable-next-line no-console
        console.log.apply(console, arguments)
      },
      printErr: function () {
        // eslint-disable-next-line no-console
        console.error.apply(console, arguments)${errorOutputsAppend}
      },
    })`
  const errorHandler = errorEvent
    ? `onError(error) {
    postMessage({ type: 'error', error, errorOutputs })
    errorOutputs.length = 0
  }`
    : ''
  const errorOutputsDecl = errorEvent ? `\nconst errorOutputs = []\n` : ''
  return `${fsImport}
${errorOutputsDecl}
const handler = new MessageHandler({
  onLoad({ wasmModule, wasmMemory }) {
    ${wasiCreation}
    return instantiateNapiModuleSync(wasmModule, {
      childThread: true,
      wasi,
      // The wasm links a "basic" emnapi archive (no C async-work /
      // threadsafe-function implementations), so every thread that
      // instantiates it must provide the JavaScript implementations
      // through the emnapi plugins.
      plugins: [emnapiAsyncWorkPlugin, emnapiTSFNPlugin],
      overwriteImports(importObject) {
        importObject.env = {
          ...importObject.env,
          ...importObject.napi,
          ...importObject.emnapi,
          memory: wasmMemory,
        }
      },
    })
  },${errorHandler ? `\n  ${errorHandler}` : ''}
})

globalThis.onmessage = function (e) {
  handler.handle(e)
}
`
}
